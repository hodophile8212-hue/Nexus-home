import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus,
  Settings,
  Wifi,
  WifiOff,
  X,
  Router,
  Eye,
  EyeOff,
  CheckCircle2,
  Droplets,
  Activity,
  Cpu,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { Space, SmartDevice, DeviceType } from './types';
import { SPACE_ICONS, MOCK_INITIAL_DATA, DEVICE_ICONS } from './constants';
import { toggleDeviceState, setDeviceLevel } from './services/espService';
import DeviceCard from './components/DeviceCard';
import { ToastContainer, ToastMessage } from './components/Toast';

// ---------------------------------------------------------------------------
// Modals & Forms
// ---------------------------------------------------------------------------

interface ModalProps {
  children?: React.ReactNode;
  isOpen: boolean;
  onClose: () => void;
  title: string;
}

const Modal = ({ children, isOpen, onClose, title }: ModalProps) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-black border border-green-900/50 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden ring-1 ring-green-900/30">
        <div className="flex justify-between items-center p-4 border-b border-gray-900">
          <h2 className="text-xl font-bold text-green-500 tracking-wide uppercase">{title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors"><X size={24} /></button>
        </div>
        <div className="p-4 max-h-[70vh] overflow-y-auto no-scrollbar">
          {children}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  // --- State ---
  const [spaces, setSpaces] = useState<Space[]>([]);
  const [devices, setDevices] = useState<SmartDevice[]>([]);
  const [activeSpaceId, setActiveSpaceId] = useState<string>('');

  // Settings State
  const [isSimulationMode, setIsSimulationMode] = useState(true);
  const [systemMode, setSystemMode] = useState<'AUTO' | 'MANUAL'>('AUTO');
  const [isEditMode, setIsEditMode] = useState(false);
  const [ssid, setSsid] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Notification State
  const [notifications, setNotifications] = useState<ToastMessage[]>([]);

  // Modals
  const [showAddSpace, setShowAddSpace] = useState(false);
  const [showAddDevice, setShowAddDevice] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showDeviceDetails, setShowDeviceDetails] = useState<SmartDevice | null>(null);

  // Form States
  const [newSpaceName, setNewSpaceName] = useState('');
  const [newSpaceIcon, setNewSpaceIcon] = useState('living_room');
  const [newDeviceName, setNewDeviceName] = useState('');
  const [newDeviceIp, setNewDeviceIp] = useState('192.168.1.');
  const [newDeviceType, setNewDeviceType] = useState<DeviceType>(DeviceType.LIGHT);
  const [newDeviceHasLevel, setNewDeviceHasLevel] = useState(false);

  // Processing state for toggles
  const [processingDevices, setProcessingDevices] = useState<Set<string>>(new Set());

  // Refs for alarm tracking
  const lastAlarmStateRef = useRef<Record<string, 'LOW' | 'HIGH' | 'NORMAL'>>({});

  // --- Initialization ---
  useEffect(() => {
    const savedSpaces = localStorage.getItem('espresso_spaces');
    const savedDevices = localStorage.getItem('espresso_devices');
    const savedNetwork = localStorage.getItem('espresso_network');

    if (savedSpaces && savedDevices) {
      setSpaces(JSON.parse(savedSpaces));
      setDevices(JSON.parse(savedDevices));
    } else {
      setSpaces(MOCK_INITIAL_DATA.spaces);
      setDevices(MOCK_INITIAL_DATA.devices);
    }

    if (savedNetwork) {
      const net = JSON.parse(savedNetwork);
      setSsid(net.ssid || '');
      setPassword(net.password || '');
    }
  }, []);

  useEffect(() => {
    if (spaces.length > 0 && !activeSpaceId) {
      setActiveSpaceId(spaces[0].id);
    }
  }, [spaces, activeSpaceId]);

  useEffect(() => {
    localStorage.setItem('espresso_spaces', JSON.stringify(spaces));
    localStorage.setItem('espresso_devices', JSON.stringify(devices));
  }, [spaces, devices]);

  useEffect(() => {
    localStorage.setItem('espresso_network', JSON.stringify({ ssid, password }));
  }, [ssid, password]);


  // --- Simulation & Automation Loop ---
  useEffect(() => {
    if (!isSimulationMode) return;

    const interval = setInterval(() => {
      setDevices(prevDevices => {
        let hasChanges = false;
        const nextDevices = prevDevices.map(d => {
          let updatedDevice = { ...d };

          // 1. Temperature Simulation
          if (updatedDevice.temperature !== undefined) {
             const change = (Math.random() - 0.5) * 0.2;
             let newTemp = updatedDevice.temperature + change;
             newTemp = Math.max(20, Math.min(30, newTemp));
             updatedDevice.temperature = newTemp;
             hasChanges = true;
          }

          // 2. Water Pump Logic
          if (updatedDevice.type === DeviceType.WATER_PUMP && updatedDevice.hasLevelSensor) {
            hasChanges = true;
            let currentLevel = updatedDevice.level || 0;
            let isOn = updatedDevice.isOn;

            // Automation only runs in AUTO mode
            if (systemMode === 'AUTO' && updatedDevice.autoEnabled) {
              const low = updatedDevice.turnOnThreshold ?? 20;
              const high = updatedDevice.turnOffThreshold ?? 90;

              if (currentLevel <= low && !isOn) {
                isOn = true;
              } else if (currentLevel >= high && isOn) {
                isOn = false;
              }
            }

            // Physics (Simulate filling/draining)
            if (isOn) {
              if (currentLevel < 100) {
                 currentLevel = Math.min(100, currentLevel + 5);
              }
            } else {
              if (currentLevel > 0) {
                 if (Math.random() > 0.7) {
                   currentLevel = Math.max(0, currentLevel - 2);
                 }
              }
            }
            updatedDevice.level = currentLevel;
            updatedDevice.isOn = isOn;
          }
          return updatedDevice;
        });

        return hasChanges ? nextDevices : prevDevices;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimulationMode, systemMode]);

  // --- Alarm Notification Monitor ---
  useEffect(() => {
    devices.forEach(d => {
      if (d.type === DeviceType.WATER_PUMP && d.hasLevelSensor) {
        const level = d.level || 0;
        const low = d.turnOnThreshold ?? 20;
        const high = d.turnOffThreshold ?? 90;

        let currentState: 'LOW' | 'HIGH' | 'NORMAL' = 'NORMAL';
        if (level <= low) currentState = 'LOW';
        else if (level >= high) currentState = 'HIGH';

        const lastState = lastAlarmStateRef.current[d.id] || 'NORMAL';

        // Detect State Change
        if (currentState !== lastState) {
          if (currentState === 'LOW') {
            addNotification(`CRITICAL: ${d.name} water level is low (${level}%)`, 'error');
          } else if (currentState === 'HIGH') {
            addNotification(`UPDATE: ${d.name} tank is full (${level}%)`, 'info');
          }

          lastAlarmStateRef.current[d.id] = currentState;
        }
      }
    });
  }, [devices]);

  // --- Handlers ---

  const addNotification = (message: string, type: 'error' | 'info' | 'success') => {
    const id = Date.now().toString() + Math.random().toString();
    setNotifications(prev => [...prev, { id, message, type }]);

    // Auto remove after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleToggleDevice = useCallback(async (device: SmartDevice) => {
    if (systemMode === 'MANUAL') {
       addNotification("Control disabled in Manual Monitor mode", "error");
       return;
    }

    if (processingDevices.has(device.id)) return;

    setProcessingDevices(prev => new Set(prev).add(device.id));

    try {
      const newState = await toggleDeviceState(device, isSimulationMode);
      setDevices(prev => prev.map(d => d.id === device.id ? { ...d, isOn: newState, isReachable: true } : d));
    } catch (e) {
      setDevices(prev => prev.map(d => d.id === device.id ? { ...d, isReachable: false } : d));
      addNotification(`Failed to connect to ${device.name}`, 'error');
    } finally {
      setProcessingDevices(prev => {
        const next = new Set(prev);
        next.delete(device.id);
        return next;
      });
    }
  }, [isSimulationMode, processingDevices, systemMode]);

  const handleLevelChange = useCallback(async (device: SmartDevice, newLevel: number) => {
    if (systemMode === 'MANUAL') return;
    setDevices(prev => prev.map(d => d.id === device.id ? { ...d, level: newLevel } : d));
    await setDeviceLevel(device, newLevel, isSimulationMode);
  }, [isSimulationMode, systemMode]);

  const handleUpdateDevice = (updatedDevice: SmartDevice) => {
    setDevices(prev => prev.map(d => d.id === updatedDevice.id ? updatedDevice : d));
  };

  const handleLongPress = (device: SmartDevice) => {
    setShowDeviceDetails(device);
  };

  const handleAddSpace = () => {
    if (!newSpaceName) return;
    const newSpace: Space = {
      id: Date.now().toString(),
      name: newSpaceName,
      iconName: newSpaceIcon
    };
    setSpaces([...spaces, newSpace]);
    setActiveSpaceId(newSpace.id);
    setNewSpaceName('');
    setShowAddSpace(false);
  };

  const handleDeleteSpace = (id: string) => {
    if (spaces.length <= 1) {
      addNotification("Cannot delete the last space.", "error");
      return;
    }
    setSpaces(prev => prev.filter(s => s.id !== id));
    setDevices(prev => prev.filter(d => d.spaceId !== id));
    if (activeSpaceId === id) {
      setActiveSpaceId(spaces.find(s => s.id !== id)?.id || '');
    }
    addNotification("Space deleted", "success");
  };

  const handleAddDevice = () => {
    if (!newDeviceName || !newDeviceIp) return;
    const newDevice: SmartDevice = {
      id: Date.now().toString(),
      name: newDeviceName,
      ipAddress: newDeviceIp,
      type: newDeviceType,
      spaceId: activeSpaceId,
      isOn: false,
      level: 0,
      temperature: 24.5,
      hasLevelSensor: newDeviceType === DeviceType.WATER_PUMP ? newDeviceHasLevel : false,
      autoEnabled: false,
      turnOnThreshold: 20,
      turnOffThreshold: 90
    };
    setDevices([...devices, newDevice]);
    setNewDeviceName('');
    setNewDeviceIp('192.168.1.');
    setNewDeviceHasLevel(false);
    setShowAddDevice(false);
    addNotification("Device added successfully", "success");
  };

  const handleDeleteDevice = (id: string) => {
    setDevices(prev => prev.filter(d => d.id !== id));
    addNotification("Device removed", "info");
  };

  // --- Render Helpers ---

  const activeSpace = spaces.find(s => s.id === activeSpaceId);
  const activeDevices = devices.filter(d => d.spaceId === activeSpaceId);
  const ActiveIcon = activeSpace ? (SPACE_ICONS[activeSpace.iconName] || SPACE_ICONS['living_room']) : SPACE_ICONS['living_room'];

  return (
    <div className="min-h-screen bg-black text-gray-200 font-sans pb-20 relative">
      <ToastContainer notifications={notifications} removeNotification={removeNotification} />

      {/* Header */}
      <header className="sticky top-0 z-30 bg-black/95 border-b border-gray-900 px-4 py-4 flex flex-col gap-4 shadow-lg shadow-black/50">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-widest text-white flex items-center gap-2 uppercase">
              <Wifi className="text-green-500" size={24} />
              Espresso
            </h1>
            <div className="flex items-center gap-2 mt-1">
               <div className={`w-2 h-2 rounded-full ${isSimulationMode ? 'bg-yellow-500' : 'bg-green-500'} shadow-[0_0_8px_currentColor]`} />
               <span className="text-[10px] text-gray-500 tracking-wider font-mono uppercase">
                 {isSimulationMode ? 'Simulation Mode' : 'Local Connected'}
               </span>
            </div>
          </div>

          <button
            onClick={() => setShowSettings(true)}
            className="p-3 rounded-full bg-gray-900 text-gray-400 hover:text-green-500 hover:bg-gray-800 transition-all border border-gray-800"
          >
            <Settings size={20} />
          </button>
        </div>

        {/* Global Mode Switch */}
        <div className="flex bg-gray-900 p-1 rounded-lg border border-gray-800">
           <button
             onClick={() => { setSystemMode('AUTO'); addNotification("Switched to Automatic Control", "success"); }}
             className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
               systemMode === 'AUTO'
                 ? 'bg-green-600 text-black shadow-lg'
                 : 'text-gray-500 hover:text-gray-300'
             }`}
           >
             <Cpu size={14} />
             Automatic
           </button>
           <button
             onClick={() => { setSystemMode('MANUAL'); addNotification("Switched to Manual Monitor", "info"); }}
             className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
               systemMode === 'MANUAL'
                 ? 'bg-red-900/50 text-red-500 border border-red-900 shadow-lg'
                 : 'text-gray-500 hover:text-gray-300'
             }`}
           >
             <Activity size={14} />
             Manual Monitor
           </button>
        </div>
      </header>

      {/* Space Selector (Horizontal Scroll) */}
      <div className="px-4 py-6 overflow-x-auto no-scrollbar flex gap-3">
        {spaces.map(space => {
          const SIcon = SPACE_ICONS[space.iconName] || SPACE_ICONS['living_room'];
          const isActive = space.id === activeSpaceId;
          return (
            <button
              key={space.id}
              onClick={() => setActiveSpaceId(space.id)}
              className={`
                relative flex items-center gap-2 px-6 py-3 rounded-xl whitespace-nowrap transition-all duration-300 border
                ${isActive
                  ? 'bg-green-600 border-green-500 text-black font-bold shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                  : 'bg-gray-900 border-gray-800 text-gray-400 hover:bg-gray-800 hover:border-gray-700'}
              `}
            >
              <SIcon size={18} />
              <span className="uppercase text-sm tracking-wide">{space.name}</span>
              {isEditMode && (
                <div
                  onClick={(e) => { e.stopPropagation(); handleDeleteSpace(space.id); }}
                  className="ml-2 p-1 bg-black/50 text-red-400 rounded-full hover:bg-red-500 hover:text-white"
                >
                  <X size={12} />
                </div>
              )}
            </button>
          );
        })}
        <button
          onClick={() => setShowAddSpace(true)}
          className="px-5 py-3 rounded-xl bg-black border border-gray-800 text-green-500 hover:border-green-500 hover:shadow-[0_0_10px_rgba(34,197,94,0.2)] transition-all"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Main Content Area */}
      <main className="px-4">
        <div className="flex items-center justify-between mb-8 border-l-4 border-green-500 pl-4 py-1">
          <h2 className="text-2xl font-bold text-white uppercase tracking-wider">
            {activeSpace?.name || "Select Space"}
          </h2>
          <ActiveIcon className="text-gray-600" size={28} />
        </div>

        {activeDevices.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-600 border border-dashed border-gray-800 rounded-2xl bg-gray-900/20">
            <WifiOff size={48} className="mb-4 opacity-30" />
            <p className="text-sm uppercase tracking-widest">No devices configured</p>
            <button
              onClick={() => setShowAddDevice(true)}
              className="mt-6 px-6 py-2 bg-green-900/30 text-green-500 border border-green-900 rounded-lg hover:bg-green-500 hover:text-black transition-all text-sm font-bold uppercase"
            >
              Add Device
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {activeDevices.map(device => (
              <DeviceCard
                key={device.id}
                device={device}
                isEditMode={isEditMode}
                systemMode={systemMode}
                onToggle={handleToggleDevice}
                onDelete={handleDeleteDevice}
                onLongPress={handleLongPress}
                onLevelChange={handleLevelChange}
                isProcessing={processingDevices.has(device.id)}
              />
            ))}
             <button
              onClick={() => setShowAddDevice(true)}
              className="flex flex-col items-center justify-center h-32 rounded-xl border border-dashed border-gray-800 text-gray-600 hover:border-green-500/50 hover:text-green-500 hover:bg-gray-900/30 transition-all group"
            >
              <Plus size={32} className="mb-2 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold uppercase tracking-widest">Add Device</span>
            </button>
          </div>
        )}
      </main>

      {/* --- Modals --- */}

      {/* Add Space Modal */}
      <Modal isOpen={showAddSpace} onClose={() => setShowAddSpace(false)} title="New Space">
        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-green-500 uppercase mb-2">Space Name</label>
            <input
              type="text"
              value={newSpaceName}
              onChange={(e) => setNewSpaceName(e.target.value)}
              placeholder="E.g. LIVING ROOM"
              className="w-full bg-gray-900 border border-gray-800 rounded-lg p-4 text-white placeholder-gray-600 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none transition-all font-medium"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-green-500 uppercase mb-2">Icon</label>
            <div className="grid grid-cols-4 gap-3">
              {Object.keys(SPACE_ICONS).map((key) => {
                const Icon = SPACE_ICONS[key];
                return (
                  <button
                    key={key}
                    onClick={() => setNewSpaceIcon(key)}
                    className={`p-4 rounded-lg flex justify-center items-center transition-all border ${newSpaceIcon === key ? 'bg-green-600 border-green-500 text-black' : 'bg-black border-gray-800 text-gray-500 hover:border-gray-600'}`}
                  >
                    <Icon size={24} />
                  </button>
                )
              })}
            </div>
          </div>
          <button
            onClick={handleAddSpace}
            className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-gray-200 transition-colors uppercase tracking-widest text-sm"
          >
            Create Space
          </button>
        </div>
      </Modal>

      {/* Add Device Modal */}
      <Modal isOpen={showAddDevice} onClose={() => setShowAddDevice(false)} title="New Device">
        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-green-500 uppercase mb-2">Device Name</label>
            <input
              type="text"
              value={newDeviceName}
              onChange={(e) => setNewDeviceName(e.target.value)}
              placeholder="E.g. CEILING FAN"
              className="w-full bg-gray-900 border border-gray-800 rounded-lg p-4 text-white placeholder-gray-600 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none transition-all font-medium"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-green-500 uppercase mb-2">Type</label>
            <select
              value={newDeviceType}
              onChange={(e) => setNewDeviceType(e.target.value as DeviceType)}
              className="w-full bg-gray-900 border border-gray-800 rounded-lg p-4 text-white focus:border-green-500 outline-none appearance-none font-medium"
            >
              {Object.values(DeviceType).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          {/* Conditional Input for Water Pump Level Sensor */}
          {newDeviceType === DeviceType.WATER_PUMP && (
            <div className="flex items-center gap-3 p-3 bg-gray-900 border border-gray-800 rounded-lg">
               <input
                 type="checkbox"
                 id="hasLevel"
                 checked={newDeviceHasLevel}
                 onChange={(e) => setNewDeviceHasLevel(e.target.checked)}
                 className="w-5 h-5 accent-green-500 bg-gray-800 border-gray-600 rounded"
               />
               <label htmlFor="hasLevel" className="text-sm font-bold text-gray-300">
                 Include Water Tank Level Sensor?
               </label>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-green-500 uppercase mb-2">IP Address</label>
            <input
              type="text"
              value={newDeviceIp}
              onChange={(e) => setNewDeviceIp(e.target.value)}
              placeholder="192.168.1.X"
              className="w-full bg-gray-900 border border-gray-800 rounded-lg p-4 text-white placeholder-gray-600 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none font-mono"
            />
          </div>
          <button
            onClick={handleAddDevice}
            className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-gray-200 transition-colors uppercase tracking-widest text-sm"
          >
            Add Device
          </button>
        </div>
      </Modal>

      {/* Settings Modal */}
      <Modal isOpen={showSettings} onClose={() => setShowSettings(false)} title="Settings">
        <div className="space-y-8">

          {/* App Controls */}
          <div className="space-y-4">
            <h3 className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4">Application</h3>
            <div className="flex items-center justify-between p-4 bg-gray-900 rounded-xl border border-gray-800">
              <span className="text-white font-medium">Edit Layout Mode</span>
              <button
                onClick={() => setIsEditMode(!isEditMode)}
                className={`w-14 h-8 rounded-full p-1 transition-colors ${isEditMode ? 'bg-green-500' : 'bg-gray-800 border border-gray-600'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform ${isEditMode ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-900 rounded-xl border border-gray-800">
              <span className="text-white font-medium">Simulation Mode</span>
              <button
                onClick={() => setIsSimulationMode(!isSimulationMode)}
                className={`w-14 h-8 rounded-full p-1 transition-colors ${isSimulationMode ? 'bg-yellow-500' : 'bg-gray-800 border border-gray-600'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform ${isSimulationMode ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>
          </div>

          {/* Network Config */}
          <div className="space-y-4">
             <div className="flex items-center gap-2 mb-2">
               <Router size={16} className="text-green-500"/>
               <h3 className="text-gray-500 text-xs font-bold uppercase tracking-widest">Network Provisioning</h3>
             </div>

             <div className="bg-gray-900 p-4 rounded-xl border border-gray-800 space-y-4">
               <div>
                 <label className="text-xs text-gray-400 block mb-2">SSID (Network Name)</label>
                 <input
                    type="text"
                    value={ssid}
                    onChange={(e) => setSsid(e.target.value)}
                    className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-green-500 outline-none font-mono text-sm"
                    placeholder="MyHomeWiFi"
                 />
               </div>
               <div>
                 <label className="text-xs text-gray-400 block mb-2">Password</label>
                 <div className="relative">
                   <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-green-500 outline-none font-mono text-sm"
                      placeholder="••••••••"
                   />
                   <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-gray-500 hover:text-white"
                   >
                     {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                   </button>
                 </div>
               </div>
               <div className="flex items-center gap-2 text-green-500 text-xs mt-2">
                  <CheckCircle2 size={12} />
                  <span>Changes saved locally</span>
               </div>
             </div>
          </div>
        </div>
      </Modal>

      {/* Device Detail Popup (Long Press) */}
      <Modal isOpen={!!showDeviceDetails} onClose={() => setShowDeviceDetails(null)} title="Device Status">
        {showDeviceDetails && (
          <div className="flex flex-col items-center justify-center space-y-6 py-6">
            <div className={`p-6 rounded-full ${showDeviceDetails.isOn ? 'bg-green-500 text-black shadow-[0_0_20px_rgba(34,197,94,0.5)]' : 'bg-gray-800 text-gray-500'}`}>
              {/* Dynamic Icon render */}
               {(() => {
                  const Icon = DEVICE_ICONS[showDeviceDetails.type] || DEVICE_ICONS[DeviceType.SWITCH];
                  return <Icon size={48} />;
               })()}
            </div>

            <div className="text-center font-mono space-y-2 w-full px-4">
              <div className="text-3xl text-white font-bold tracking-tighter">
                {showDeviceDetails.ipAddress}
              </div>
              <div className="text-green-500 text-xl font-bold">
                 /{showDeviceDetails.name.toUpperCase()}/{showDeviceDetails.isOn ? 'ON' : 'OFF'}
              </div>

              {/* Detailed Level Info */}
              {showDeviceDetails.level !== undefined && (
                <div className="mt-4 p-3 bg-gray-900 rounded-lg border border-gray-800">
                  <p className="text-gray-400 text-sm">CURRENT LEVEL</p>
                  <p className="text-2xl text-white font-bold">{showDeviceDetails.level}%</p>
                </div>
              )}

               {/* Detailed Temperature Info */}
              {showDeviceDetails.temperature !== undefined && (
                <div className="mt-2 p-3 bg-gray-900 rounded-lg border border-gray-800">
                  <p className="text-gray-400 text-sm">TEMPERATURE</p>
                  <p className="text-2xl text-blue-400 font-bold">{showDeviceDetails.temperature.toFixed(1)}°C</p>
                </div>
              )}

              {/* Automation Settings for Water Pump */}
              {showDeviceDetails.type === DeviceType.WATER_PUMP && showDeviceDetails.hasLevelSensor && (
                 <div className="mt-6 w-full text-left bg-gray-900 border border-gray-800 p-4 rounded-xl">
                    <div className="flex items-center justify-between mb-4">
                       <div className="flex items-center gap-2">
                         <Activity size={18} className="text-green-500" />
                         <span className="font-bold text-white text-sm uppercase tracking-wider">Automation</span>
                       </div>
                       <div
                         onClick={() => {
                            if (systemMode === 'MANUAL') return;
                            const updated = { ...showDeviceDetails, autoEnabled: !showDeviceDetails.autoEnabled };
                            setShowDeviceDetails(updated);
                            handleUpdateDevice(updated);
                         }}
                         className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${showDeviceDetails.autoEnabled && systemMode === 'AUTO' ? 'bg-green-500' : 'bg-gray-800 border border-gray-600'}`}
                       >
                         <div className={`w-4 h-4 bg-white rounded-full shadow transition-transform ${showDeviceDetails.autoEnabled ? 'translate-x-6' : ''}`} />
                       </div>
                    </div>

                    {showDeviceDetails.autoEnabled && (
                      <div className="grid grid-cols-2 gap-4">
                         <div>
                           <label className="text-[10px] font-bold text-gray-500 block mb-1">TURN ON BELOW (%)</label>
                           <input
                             type="number"
                             min="0"
                             max="100"
                             value={showDeviceDetails.turnOnThreshold ?? 20}
                             onChange={(e) => {
                               const val = parseInt(e.target.value);
                               const updated = { ...showDeviceDetails, turnOnThreshold: val };
                               setShowDeviceDetails(updated);
                               handleUpdateDevice(updated);
                             }}
                             className="w-full bg-black border border-gray-700 rounded p-2 text-white font-mono text-center focus:border-green-500 outline-none"
                           />
                         </div>
                         <div>
                           <label className="text-[10px] font-bold text-gray-500 block mb-1">TURN OFF ABOVE (%)</label>
                           <input
                             type="number"
                             min="0"
                             max="100"
                             value={showDeviceDetails.turnOffThreshold ?? 90}
                             onChange={(e) => {
                               const val = parseInt(e.target.value);
                               const updated = { ...showDeviceDetails, turnOffThreshold: val };
                               setShowDeviceDetails(updated);
                               handleUpdateDevice(updated);
                             }}
                             className="w-full bg-black border border-gray-700 rounded p-2 text-white font-mono text-center focus:border-green-500 outline-none"
                           />
                         </div>
                      </div>
                    )}
                 </div>
              )}
            </div>
          </div>
        )}
      </Modal>

    </div>
  );
}