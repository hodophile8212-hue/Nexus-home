import React, { useRef } from 'react';
import { Trash2, WifiOff, AlertTriangle, Thermometer } from 'lucide-react';
import { SmartDevice, DeviceType } from '../types';
import { DEVICE_ICONS } from '../constants';

interface DeviceCardProps {
  device: SmartDevice;
  isEditMode: boolean;
  systemMode: 'AUTO' | 'MANUAL';
  onToggle: (device: SmartDevice) => void;
  onDelete: (id: string) => void;
  onLongPress: (device: SmartDevice) => void;
  onLevelChange: (device: SmartDevice, level: number) => void;
  isProcessing: boolean;
}

const DeviceCard: React.FC<DeviceCardProps> = ({
  device,
  isEditMode,
  systemMode,
  onToggle,
  onDelete,
  onLongPress,
  onLevelChange,
  isProcessing
}) => {
  const Icon = DEVICE_ICONS[device.type] || DEVICE_ICONS[DeviceType.SWITCH];
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Alarm Conditions for Water Pump using custom thresholds
  const isWaterPump = device.type === DeviceType.WATER_PUMP && device.hasLevelSensor;
  const lowThreshold = device.turnOnThreshold ?? 20;
  const highThreshold = device.turnOffThreshold ?? 90;

  const isLowLevel = isWaterPump && (device.level || 0) <= lowThreshold;
  const isFullLevel = isWaterPump && (device.level || 0) >= highThreshold;

  // Visual cues for alarms
  const getBorderColor = () => {
    if (isLowLevel) return 'border-red-500 animate-pulse';
    if (isFullLevel) return 'border-blue-400';
    if (device.isOn) return 'border-green-500';
    return 'border-gray-800';
  };

  const getBgColor = () => {
    if (isLowLevel) return 'bg-red-900/10';
    if (isFullLevel) return 'bg-blue-900/10';
    if (device.isOn) return 'bg-green-900/20';
    return 'bg-gray-900';
  };

  const handleStart = () => {
    timerRef.current = setTimeout(() => {
      onLongPress(device);
    }, 600);
  };

  const handleEnd = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const isManual = systemMode === 'MANUAL';
  const controlsDisabled = isManual || isProcessing;

  return (
    <div
      className={`
        relative group overflow-hidden rounded-xl p-4 transition-all duration-300 select-none border
        ${getBgColor()}
        ${getBorderColor()}
        ${device.isOn ? 'shadow-[0_0_10px_rgba(34,197,94,0.1)]' : 'hover:border-gray-700'}
        ${isManual ? 'opacity-90' : ''}
      `}
      onTouchStart={handleStart}
      onTouchEnd={handleEnd}
      onMouseDown={handleStart}
      onMouseUp={handleEnd}
      onMouseLeave={handleEnd}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="flex justify-between items-start mb-3">
        <div
          className={`
            p-3 rounded-full transition-colors duration-300 relative
            ${device.isOn ? 'bg-green-500 text-black' : 'bg-black text-gray-500 border border-gray-800'}
            ${isLowLevel ? 'bg-red-500 text-white animate-bounce' : ''}
            ${isFullLevel ? 'bg-blue-500 text-white' : ''}
          `}
        >
          <Icon size={24} />
          {isLowLevel && <AlertTriangle size={12} className="absolute -top-1 -right-1 text-red-500 bg-black rounded-full" />}
          {device.autoEnabled && isWaterPump && systemMode === 'AUTO' && (
             <div className="absolute -bottom-1 -right-1 bg-green-900 text-[8px] text-green-200 px-1 rounded border border-green-700 font-bold">AUTO</div>
          )}
        </div>

        {/* Toggle Switch - Disabled in Manual Mode */}
        {!isEditMode && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (!controlsDisabled) onToggle(device);
            }}
            disabled={controlsDisabled}
            className={`
              w-12 h-6 rounded-full p-1 transition-colors duration-300 focus:outline-none
              ${device.isOn ? 'bg-green-500' : 'bg-gray-800 border border-gray-700'}
              ${controlsDisabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}
            `}
          >
            <div
              className={`
                bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out
                ${device.isOn ? 'translate-x-6' : 'translate-x-0'}
              `}
            />
          </button>
        )}

        {/* Edit Controls */}
        {isEditMode && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete(device.id);
            }}
            className="text-red-500 hover:text-red-400 p-1 rounded-full hover:bg-red-900/20 transition-colors"
          >
            <Trash2 size={20} />
          </button>
        )}
      </div>

      <div className="mb-2">
        <h3 className={`text-lg font-bold leading-tight truncate ${device.isOn ? 'text-white' : 'text-gray-300'}`}>
          {device.name}
        </h3>

        <div className="flex items-center gap-3 mt-2">
          {/* Temperature Display */}
          {device.temperature !== undefined && (
            <div className="flex items-center gap-1 text-xs font-mono text-blue-400 bg-blue-900/20 px-1.5 py-0.5 rounded border border-blue-900/50">
               <Thermometer size={10} />
               <span>{device.temperature.toFixed(1)}°C</span>
            </div>
          )}

          {/* Connectivity Status */}
          {device.isReachable === false && (
            <div className="flex items-center gap-1 text-red-500 text-xs font-bold">
              <WifiOff size={12} />
              <span>OFFLINE</span>
            </div>
          )}
        </div>

        {/* Water Pump Status Text */}
        {isWaterPump && (
          <div className="mt-2 flex items-center justify-between text-xs font-bold font-mono">
            <span className={isLowLevel ? 'text-red-500' : isFullLevel ? 'text-blue-400' : 'text-gray-400'}>
               {isLowLevel ? 'LOW LEVEL ALARM' : isFullLevel ? 'TANK FULL' : `${device.level}%`}
            </span>
          </div>
        )}
      </div>

      {/* --- Fan Regulator (Slider) --- */}
      {device.type === DeviceType.FAN && (
        <div
          className={`mt-3 ${isManual ? 'opacity-50 pointer-events-none' : ''}`}
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between text-[10px] text-gray-500 font-bold mb-1 uppercase">
            <span>Low</span>
            <span>High</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={device.level || 0}
            onChange={(e) => onLevelChange(device, parseInt(e.target.value))}
            className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-green-500"
            disabled={isManual}
          />
        </div>
      )}

      {/* --- Water Tank Level Indicator (Bar) --- */}
      {isWaterPump && (
        <div className="mt-3 w-full h-3 bg-gray-900 rounded-full border border-gray-800 overflow-hidden relative">
           {/* Level Bar */}
           <div
             className={`h-full transition-all duration-500 ease-out
               ${isLowLevel ? 'bg-red-600' : isFullLevel ? 'bg-blue-500' : 'bg-blue-600/60'}
             `}
             style={{ width: `${device.level || 0}%` }}
           />
           {/* Threshold Markers */}
           <div className="absolute inset-0 pointer-events-none">
             <div
               className="absolute top-0 bottom-0 w-0.5 bg-red-500/50"
               style={{ left: `${lowThreshold}%` }}
             />
             <div
               className="absolute top-0 bottom-0 w-0.5 bg-blue-500/50"
               style={{ left: `${highThreshold}%` }}
             />
           </div>
        </div>
      )}

    </div>
  );
};

export default DeviceCard;