import React from 'react';
import { X, AlertTriangle, Droplets, Info, CheckCircle2 } from 'lucide-react';

export interface ToastMessage {
  id: string;
  message: string;
  type: 'error' | 'info' | 'success';
}

interface ToastProps {
  notifications: ToastMessage[];
  removeNotification: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ notifications, removeNotification }) => {
  return (
    <div className="fixed top-4 left-0 right-0 z-[100] flex flex-col items-center gap-2 pointer-events-none px-4">
      {notifications.map((notif) => (
        <div
          key={notif.id}
          className={`
            pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl border backdrop-blur-md w-full max-w-sm animate-in slide-in-from-top-2 fade-in duration-300
            ${notif.type === 'error' ? 'bg-red-950/90 border-red-500 text-white' : ''}
            ${notif.type === 'info' ? 'bg-blue-950/90 border-blue-500 text-white' : ''}
            ${notif.type === 'success' ? 'bg-green-950/90 border-green-500 text-white' : ''}
          `}
        >
          <div className={`p-1 rounded-full ${
            notif.type === 'error' ? 'bg-red-500/20' :
            notif.type === 'info' ? 'bg-blue-500/20' : 'bg-green-500/20'
          }`}>
            {notif.type === 'error' && <AlertTriangle size={18} className="text-red-400" />}
            {notif.type === 'info' && <Droplets size={18} className="text-blue-400" />}
            {notif.type === 'success' && <CheckCircle2 size={18} className="text-green-400" />}
          </div>

          <span className="text-sm font-bold flex-1 tracking-wide">{notif.message}</span>

          <button
            onClick={() => removeNotification(notif.id)}
            className="p-1 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white"
          >
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
};