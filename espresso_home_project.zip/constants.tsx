import React from 'react';
import {
  Lightbulb,
  Fan,
  Power,
  Plug,
  Lock,
  Sofa,
  Utensils,
  BedDouble,
  Bath,
  Tv,
  Briefcase,
  Droplets
} from 'lucide-react';
import { DeviceType } from './types';

// Map DeviceType to Lucide Icons
export const DEVICE_ICONS: Record<DeviceType, React.ElementType> = {
  [DeviceType.LIGHT]: Lightbulb,
  [DeviceType.FAN]: Fan,
  [DeviceType.SWITCH]: Power,
  [DeviceType.OUTLET]: Plug,
  [DeviceType.LOCK]: Lock,
  [DeviceType.WATER_PUMP]: Droplets,
};

// Available Space Icons for selection
export const SPACE_ICONS: Record<string, React.ElementType> = {
  'living_room': Sofa,
  'kitchen': Utensils,
  'bedroom': BedDouble,
  'bathroom': Bath,
  'entertainment': Tv,
  'office': Briefcase,
};

export const MOCK_INITIAL_DATA = {
  spaces: [
    { id: '1', name: 'Living Room', iconName: 'living_room' },
    { id: '2', name: 'Kitchen', iconName: 'kitchen' },
  ],
  devices: [
    { id: 'd1', name: 'Main Light', type: DeviceType.LIGHT, ipAddress: '192.168.1.101', spaceId: '1', isOn: true, temperature: 24 },
    { id: 'd2', name: 'Ceiling Fan', type: DeviceType.FAN, ipAddress: '192.168.1.102', spaceId: '1', isOn: false, level: 50, temperature: 23.5 },
    { id: 'd3', name: 'Main Pump', type: DeviceType.WATER_PUMP, ipAddress: '192.168.1.103', spaceId: '2', isOn: false, hasLevelSensor: true, level: 45, temperature: 22, autoEnabled: true },
  ]
};