import { SmartDevice } from "../types";

/**
 * Sends a toggle command to the ESP8266.
 * Expects the ESP8266 to have an endpoint like: GET /toggle or GET /control?state=ON/OFF
 * For this demo, we assume a simple REST pattern: http://<ip>/<action>
 *
 * Note: Browsers block requests to local IP addresses from HTTPS origins due to Mixed Content.
 * If this app is served via HTTPS (like Vercel), real local requests will fail unless the user
 * enables specific browser flags or uses a localhost proxy.
 */

export const toggleDeviceState = async (device: SmartDevice, simulate: boolean = false): Promise<boolean> => {
  if (simulate) {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 300));
    return !device.isOn;
  }

  try {
    const targetState = device.isOn ? 'off' : 'on';
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000); // 2s timeout for local devices

    // Example Tasmota syntax: http://192.168.1.X/cm?cmnd=Power%20TOGGLE
    // Example Simple Server syntax: http://192.168.1.X/on
    // We will use a generic path structure here.
    const response = await fetch(`http://${device.ipAddress}/${targetState}`, {
      method: 'GET',
      signal: controller.signal,
      mode: 'cors', // The ESP8266 MUST handle CORS headers
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      return !device.isOn;
    }
    return device.isOn; // No change if failed
  } catch (error) {
    console.error(`Failed to connect to device at ${device.ipAddress}`, error);
    throw new Error("Device unreachable");
  }
};

export const setDeviceLevel = async (device: SmartDevice, level: number, simulate: boolean = false): Promise<boolean> => {
  if (simulate) {
    return true;
  }

  try {
    // Example: http://192.168.1.X/level?value=50
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1000);

    await fetch(`http://${device.ipAddress}/level?value=${level}`, {
      method: 'GET',
      signal: controller.signal,
      mode: 'cors'
    });

    clearTimeout(timeoutId);
    return true;
  } catch (e) {
    console.error("Failed to set level", e);
    return false;
  }
};