import { GoogleGenAI, Type } from "@google/genai";

// Schema for the expected JSON output from Gemini
const homeConfigSchema = {
  type: Type.OBJECT,
  properties: {
    spaces: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Name of the room (e.g., Living Room)" },
          iconName: { type: Type.STRING, description: "One of: living_room, kitchen, bedroom, bathroom, entertainment, office" },
          devices: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: "Device name" },
                type: { type: Type.STRING, description: "One of: LIGHT, FAN, SWITCH, OUTLET, LOCK" },
                ipAddress: { type: Type.STRING, description: "A placeholder local IP (e.g., 192.168.1.x)" }
              },
              required: ["name", "type", "ipAddress"]
            }
          }
        },
        required: ["name", "iconName", "devices"]
      }
    }
  },
  required: ["spaces"]
};

export const generateHomeConfig = async (prompt: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // We use gemini-2.5-flash for fast JSON generation
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a smart home configuration based on this description: "${prompt}".
      Assign appropriate icons and device types.
      Generate placeholder IP addresses starting with 192.168.1.100 and incrementing.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: homeConfigSchema,
        systemInstruction: "You are a smart home configuration assistant. Always return valid JSON matching the schema.",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text);

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};