export enum DeviceType {
  LIGHT = 'LIGHT',
  FAN = 'FAN',
  SWITCH = 'SWITCH',
  OUTLET = 'OUTLET',
  LOCK = 'LOCK',
  WATER_PUMP = 'WATER_PUMP'
}

export interface SmartDevice {
  id: string;
  name: string;
  type: DeviceType;
  ipAddress: string; // e.g., 192.168.1.50
  spaceId: string;
  isOn: boolean;
  isReachable?: boolean;
  level?: number; // 0-100: Fan Speed or Water Level
  hasLevelSensor?: boolean; // Specific to Water Tanks
  temperature?: number; // Ambient temperature in Celsius
  // Automation properties
  autoEnabled?: boolean;
  turnOnThreshold?: number; // Low level to trigger ON
  turnOffThreshold?: number; // High level to trigger OFF
}

export interface Space {
  id: string;
  name: string;
  iconName: string; // maps to lucide icons
}

export interface AppState {
  spaces: Space[];
  devices: SmartDevice[];
}

export interface ESPResponse {
  success: boolean;
  state?: 'ON' | 'OFF';
  message?: string;
}